# __init__.py
from .jfw_generator import *
from .jfw_structs import *
from .jfw_deserializer import deserializer

# Version of the jfw-encoder-decoder package
__version__ = "1.1.2"